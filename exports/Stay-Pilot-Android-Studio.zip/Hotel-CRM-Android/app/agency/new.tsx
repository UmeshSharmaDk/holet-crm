import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import Colors from "@/constants/colors";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import { ScrollView } from "@/components/RefreshablePages";
import { useEffectiveHotelId } from "@/components/HotelPicker";

const C = Colors.light;

export default function NewAgencyScreen() {
  const { user } = useAuth();
  // Same as the booking form: an admin's own hotelId is null, so the hotel has
  // to come from the picker rather than from the user record.
  const effectiveHotelId = useEffectiveHotelId();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const [form, setForm] = useState({ name: "", contactEmail: "", contactPhone: "" });

  const mutation = useMutation({
    mutationFn: (data: any) => api.post("/agencies", data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["agencies"] });
      router.back();
    },
    onError: (e: any) => Alert.alert("Error", e.message),
  });

  function submit() {
    if (!form.name.trim()) { Alert.alert("Error", "Agency name is required"); return; }
    if (!effectiveHotelId) {
      Alert.alert("Error", user?.role === "admin"
        ? "Select a specific hotel before creating an agency."
        : "Your account is not assigned to a hotel.");
      return;
    }
    mutation.mutate({
      name: form.name.trim(),
      contactEmail: form.contactEmail.trim() || null,
      contactPhone: form.contactPhone.trim() || null,
      hotelId: effectiveHotelId,
    });
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.topBar}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={C.text} />
        </Pressable>
        <Text style={styles.topTitle}>New Agency</Text>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <View style={styles.iconHeader}>
            <View style={styles.iconWrap}>
              <Feather name="briefcase" size={32} color={C.primary} />
            </View>
            <Text style={styles.iconLabel}>Travel Agency</Text>
          </View>

          <FormField label="Agency Name *" value={form.name} onChangeText={(v: string) => setForm((f) => ({ ...f, name: v }))} placeholder="Grand Travel Agency" />
          <FormField label="Contact Email" value={form.contactEmail} onChangeText={(v: string) => setForm((f) => ({ ...f, contactEmail: v }))} placeholder="contact@agency.com" keyboardType="email-address" />
          <FormField label="Contact Phone" value={form.contactPhone} onChangeText={(v: string) => setForm((f) => ({ ...f, contactPhone: v }))} placeholder="+1 234 567 8900" keyboardType="phone-pad" />

          <Pressable
            style={({ pressed }) => [styles.submitBtn, pressed && { opacity: 0.85 }, mutation.isPending && { opacity: 0.6 }]}
            onPress={submit}
            disabled={mutation.isPending}
          >
            {mutation.isPending
              ? <ActivityIndicator color="#fff" size="small" />
              : <><Feather name="plus" size={20} color="#fff" /><Text style={styles.submitText}>Create Agency</Text></>}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

function FormField({ label, value, onChangeText, placeholder, keyboardType }: any) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={styles.fieldInput}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={C.textSecondary}
        keyboardType={keyboardType ?? "default"}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.background },
  topBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, gap: 12 },
  backBtn: { padding: 4 },
  topTitle: { fontFamily: "Inter_700Bold", fontSize: 22, color: C.text },
  content: { paddingHorizontal: 20, paddingBottom: 40 },
  iconHeader: { alignItems: "center", paddingVertical: 24 },
  iconWrap: { width: 72, height: 72, borderRadius: 20, backgroundColor: C.accentLight, justifyContent: "center", alignItems: "center", marginBottom: 8 },
  iconLabel: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: C.textSecondary },
  field: { marginBottom: 16 },
  fieldLabel: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: C.text, marginBottom: 8 },
  fieldInput: { borderWidth: 1.5, borderColor: C.border, borderRadius: 12, padding: 14, fontFamily: "Inter_400Regular", fontSize: 15, color: C.text, backgroundColor: C.surface },
  submitBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: C.primary, borderRadius: 14, paddingVertical: 18, marginTop: 12 },
  submitText: { fontFamily: "Inter_700Bold", fontSize: 16, color: "#fff" },
});
